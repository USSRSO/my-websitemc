import { useState, useEffect, useMemo, useRef, useCallback } from "react";

// Types
type User = {
  id: string;
  username: string;
  email: string;
  passwordHash: string;
  createdAt: string;
  isAdmin?: boolean;
};

type Task = {
  id: string;
  userId: string;
  title: string;
  category: "study" | "workout" | "work" | "personal" | "other";
  completed: boolean;
  createdAt: string;
  completedAt?: string;
};

type Session = {
  token: string;
  userId: string;
  expiresAt: number;
};

// Storage keys
const USERS_KEY = "hypertrack_users";
const TASKS_KEY = "hypertrack_tasks";
const SESSION_KEY = "hypertrack_session";

// Admin credentials
const ADMIN_EMAIL = "root.hyper@cloud.com";
const ADMIN_PASSWORD = "aarav123";

// Simple hash function (for demo - in production use bcrypt)
const simpleHash = (str: string): string => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
};

// JWT-like token generator
const generateToken = (userId: string): string => {
  const header = btoa(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const payload = btoa(JSON.stringify({ userId, exp: Date.now() + 7 * 24 * 60 * 60 * 1000 }));
  const signature = simpleHash(header + "." + payload);
  return `${header}.${payload}.${signature}`;
};

const verifyToken = (token: string): { valid: boolean; userId?: string } => {
  try {
    const [header, payload, signature] = token.split(".");
    const expectedSig = simpleHash(header + "." + payload);
    if (signature !== expectedSig) return { valid: false };
    const data = JSON.parse(atob(payload));
    if (data.exp < Date.now()) return { valid: false };
    return { valid: true, userId: data.userId };
  } catch {
    return { valid: false };
  }
};

// Storage helpers
const getUsers = (): User[] => {
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
  } catch {
    return [];
  }
};

const saveUsers = (users: User[]) => {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

const getTasks = (): Task[] => {
  try {
    return JSON.parse(localStorage.getItem(TASKS_KEY) || "[]");
  } catch {
    return [];
  }
};

const saveTasks = (tasks: Task[]) => {
  localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
};

const getSession = (): Session | null => {
  try {
    const s = localStorage.getItem(SESSION_KEY);
    return s ? JSON.parse(s) : null;
  } catch {
    return null;
  }
};

const saveSession = (session: Session) => {
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
};

const clearSession = () => {
  localStorage.removeItem(SESSION_KEY);
};

// Initialize admin user
const initializeAdmin = () => {
  const users = getUsers();
  if (!users.find(u => u.email === ADMIN_EMAIL)) {
    users.push({
      id: "admin-1",
      username: "Hyper Root",
      email: ADMIN_EMAIL,
      passwordHash: simpleHash(ADMIN_PASSWORD),
      createdAt: new Date().toISOString(),
      isAdmin: true,
    });
    saveUsers(users);
  }
};

// Trading-style chart component
function TradingChart({ data }: { data: { date: string; completion: number }[] }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || data.length === 0) return;
    
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);
    
    const width = rect.width;
    const height = rect.height;
    const padding = { top: 20, right: 20, bottom: 40, left: 50 };
    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom;

    // Clear
    ctx.clearRect(0, 0, width, height);

    // Background grid
    ctx.strokeStyle = "rgba(148, 163, 184, 0.1)";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = padding.top + (chartHeight / 4) * i;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(width - padding.right, y);
      ctx.stroke();
      
      // Y-axis labels
      ctx.fillStyle = "rgba(148, 163, 184, 0.6)";
      ctx.font = "10px 'JetBrains Mono'";
      ctx.textAlign = "right";
      ctx.fillText(`${100 - i * 25}%`, padding.left - 8, y + 3);
    }

    // X-axis labels
    data.forEach((_, i) => {
      const x = padding.left + (chartWidth / (data.length - 1)) * i;
      if (i % Math.max(1, Math.floor(data.length / 7)) === 0) {
        ctx.fillStyle = "rgba(148, 163, 184, 0.6)";
        ctx.font = "10px 'JetBrains Mono'";
        ctx.textAlign = "center";
        const date = new Date(data[i].date);
        ctx.fillText(`${date.getMonth() + 1}/${date.getDate()}`, x, height - 15);
      }
    });

    // Create gradient for area
    const gradient = ctx.createLinearGradient(0, padding.top, 0, padding.top + chartHeight);
    gradient.addColorStop(0, "rgba(99, 102, 241, 0.3)");
    gradient.addColorStop(1, "rgba(99, 102, 241, 0)");

    // Draw area
    ctx.beginPath();
    data.forEach((point, i) => {
      const x = padding.left + (chartWidth / (data.length - 1)) * i;
      const y = padding.top + chartHeight - (point.completion / 100) * chartHeight;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.lineTo(padding.left + chartWidth, padding.top + chartHeight);
    ctx.lineTo(padding.left, padding.top + chartHeight);
    ctx.closePath();
    ctx.fillStyle = gradient;
    ctx.fill();

    // Draw line with glow
    ctx.shadowColor = "rgba(99, 102, 241, 0.5)";
    ctx.shadowBlur = 10;
    ctx.beginPath();
    data.forEach((point, i) => {
      const x = padding.left + (chartWidth / (data.length - 1)) * i;
      const y = padding.top + chartHeight - (point.completion / 100) * chartHeight;
      if (i === 0) ctx.moveTo(x, y);
      else {
        // Smooth curve using quadratic
        const prevX = padding.left + (chartWidth / (data.length - 1)) * (i - 1);
        const prevY = padding.top + chartHeight - (data[i - 1].completion / 100) * chartHeight;
        const cpX = (prevX + x) / 2;
        ctx.quadraticCurveTo(cpX, prevY, x, y);
      }
    });
    ctx.strokeStyle = "#6366f1";
    ctx.lineWidth = 2.5;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Draw points
    data.forEach((point, i) => {
      const x = padding.left + (chartWidth / (data.length - 1)) * i;
      const y = padding.top + chartHeight - (point.completion / 100) * chartHeight;
      
      // Outer glow
      const glowGrad = ctx.createRadialGradient(x, y, 0, x, y, 12);
      glowGrad.addColorStop(0, "rgba(99, 102, 241, 0.4)");
      glowGrad.addColorStop(1, "rgba(99, 102, 241, 0)");
      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.arc(x, y, 12, 0, Math.PI * 2);
      ctx.fill();

      // Point
      ctx.fillStyle = i === hoverIndex ? "#a5b4fc" : "#6366f1";
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fill();

      // Inner highlight
      ctx.fillStyle = "rgba(255, 255, 255, 0.8)";
      ctx.beginPath();
      ctx.arc(x, y, 1.5, 0, Math.PI * 2);
      ctx.fill();
    });

  }, [data, hoverIndex]);

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || data.length === 0) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const padding = { left: 50, right: 20 };
    const chartWidth = rect.width - padding.left - padding.right;
    
    const relativeX = x - padding.left;
    const index = Math.round((relativeX / chartWidth) * (data.length - 1));
    
    if (index >= 0 && index < data.length && relativeX >= 0 && relativeX <= chartWidth) {
      setHoverIndex(index);
      setMousePos({ x: e.clientX, y: e.clientY });
    } else {
      setHoverIndex(null);
    }
  };

  return (
    <div className="relative">
      <canvas
        ref={canvasRef}
        className="w-full h-[280px] cursor-crosshair"
        onMouseMove={handleMouseMove}
        onMouseLeave={() => setHoverIndex(null)}
      />
      {hoverIndex !== null && (
        <div
          className="fixed z-50 pointer-events-none"
          style={{
            left: mousePos.x + 12,
            top: mousePos.y - 60,
          }}
        >
          <div className="bg-slate-900/95 backdrop-blur-xl border border-slate-700/50 rounded-xl px-3 py-2 shadow-2xl">
            <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Completion</div>
            <div className="text-lg font-semibold text-white font-mono">
              {data[hoverIndex].completion.toFixed(1)}%
            </div>
            <div className="text-[10px] text-slate-500 font-mono">
              {new Date(data[hoverIndex].date).toLocaleDateString()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [currentView, setCurrentView] = useState<"home" | "dashboard" | "admin-login" | "admin-dashboard">("home");
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [tasks, setTasks] = useState<Task[]>([]);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskCategory, setNewTaskCategory] = useState<Task["category"]>("personal");
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Form states
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [registerUsername, setRegisterUsername] = useState("");
  const [registerEmail, setRegisterEmail] = useState("");
  const [registerPassword, setRegisterPassword] = useState("");

  // Initialize
  useEffect(() => {
    initializeAdmin();
    const session = getSession();
    if (session) {
      const verification = verifyToken(session.token);
      if (verification.valid && verification.userId) {
        const users = getUsers();
        const user = users.find(u => u.id === verification.userId);
        if (user) {
          setCurrentUser(user);
          setCurrentView(user.isAdmin ? "admin-dashboard" : "dashboard");
          const allTasks = getTasks();
          setTasks(allTasks.filter(t => t.userId === user.id));
        } else {
          clearSession();
        }
      } else {
        clearSession();
      }
    }
  }, []);

  // Derived data
  const todayTasks = useMemo(() => {
    const today = new Date().toDateString();
    return tasks.filter(t => new Date(t.createdAt).toDateString() === today);
  }, [tasks]);

  const completedTasks = useMemo(() => todayTasks.filter(t => t.completed), [todayTasks]);
  const pendingTasks = useMemo(() => todayTasks.filter(t => !t.completed), [todayTasks]);
  
  const completionPercentage = useMemo(() => {
    if (todayTasks.length === 0) return 0;
    return Math.round((completedTasks.length / todayTasks.length) * 100);
  }, [todayTasks, completedTasks]);

  const streak = useMemo(() => {
    const userTasks = tasks.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    let streakCount = 0;
    let currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);

    for (let i = 0; i < 365; i++) {
      const dateStr = currentDate.toDateString();
      const dayTasks = userTasks.filter(t => new Date(t.createdAt).toDateString() === dateStr);
      if (dayTasks.length > 0 && dayTasks.every(t => t.completed)) {
        streakCount++;
      } else if (i > 0 || dayTasks.length > 0) {
        break;
      }
      currentDate.setDate(currentDate.getDate() - 1);
    }
    return streakCount;
  }, [tasks]);

  // Weekly chart data
  const chartData = useMemo(() => {
    const data: { date: string; completion: number }[] = [];
    const today = new Date();
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = date.toDateString();
      const dayTasks = tasks.filter(t => new Date(t.createdAt).toDateString() === dateStr);
      const completed = dayTasks.filter(t => t.completed).length;
      const percentage = dayTasks.length > 0 ? (completed / dayTasks.length) * 100 : 0;
      data.push({ date: date.toISOString(), completion: Math.round(percentage * 10) / 10 });
    }
    return data;
  }, [tasks]);

  // Handlers
  const showMessage = useCallback((msg: string, isError = false) => {
    if (isError) {
      setError(msg);
      setSuccess("");
    } else {
      setSuccess(msg);
      setError("");
    }
    setTimeout(() => {
      setError("");
      setSuccess("");
    }, 3000);
  }, []);

  const handleRegister = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (!registerUsername.trim() || !registerEmail.trim() || !registerPassword.trim()) {
      showMessage("All fields are required", true);
      return;
    }
    
    if (registerPassword.length < 6) {
      showMessage("Password must be at least 6 characters", true);
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(registerEmail)) {
      showMessage("Please enter a valid email", true);
      return;
    }

    const users = getUsers();
    if (users.find(u => u.email.toLowerCase() === registerEmail.toLowerCase())) {
      showMessage("Email already registered", true);
      return;
    }

    const newUser: User = {
      id: "user-" + Date.now(),
      username: registerUsername.trim(),
      email: registerEmail.trim().toLowerCase(),
      passwordHash: simpleHash(registerPassword),
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);
    saveUsers(users);
    
    const token = generateToken(newUser.id);
    saveSession({ token, userId: newUser.id, expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000 });
    
    setCurrentUser(newUser);
    setTasks([]);
    setCurrentView("dashboard");
    showMessage("Account created successfully!");
    
    setRegisterUsername("");
    setRegisterEmail("");
    setRegisterPassword("");
  }, [registerUsername, registerEmail, registerPassword, showMessage]);

  const handleLogin = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (!loginEmail.trim() || !loginPassword.trim()) {
      showMessage("Email and password are required", true);
      return;
    }

    const users = getUsers();
    const user = users.find(u => u.email.toLowerCase() === loginEmail.toLowerCase());
    
    if (!user || user.passwordHash !== simpleHash(loginPassword)) {
      showMessage("Invalid email or password", true);
      return;
    }

    const token = generateToken(user.id);
    saveSession({ token, userId: user.id, expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000 });
    
    setCurrentUser(user);
    const allTasks = getTasks();
    setTasks(allTasks.filter(t => t.userId === user.id));
    setCurrentView(user.isAdmin ? "admin-dashboard" : "dashboard");
    showMessage("Logged in successfully!");
    
    setLoginEmail("");
    setLoginPassword("");
  }, [loginEmail, loginPassword, showMessage]);

  const handleLogout = useCallback(() => {
    clearSession();
    setCurrentUser(null);
    setTasks([]);
    setCurrentView("home");
    showMessage("Logged out successfully");
  }, [showMessage]);

  const handleAddTask = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim() || !currentUser) return;

    const newTask: Task = {
      id: "task-" + Date.now(),
      userId: currentUser.id,
      title: newTaskTitle.trim(),
      category: newTaskCategory,
      completed: false,
      createdAt: new Date().toISOString(),
    };

    const allTasks = getTasks();
    allTasks.push(newTask);
    saveTasks(allTasks);
    setTasks(prev => [...prev, newTask]);
    setNewTaskTitle("");
    showMessage("Task added");
  }, [newTaskTitle, newTaskCategory, currentUser, showMessage]);

  const toggleTask = useCallback((taskId: string) => {
    if (!currentUser) return;
    
    const allTasks = getTasks();
    const taskIndex = allTasks.findIndex(t => t.id === taskId && t.userId === currentUser.id);
    if (taskIndex === -1) return;

    allTasks[taskIndex].completed = !allTasks[taskIndex].completed;
    allTasks[taskIndex].completedAt = allTasks[taskIndex].completed ? new Date().toISOString() : undefined;
    saveTasks(allTasks);
    
    setTasks(prev => prev.map(t => 
      t.id === taskId 
        ? { ...t, completed: !t.completed, completedAt: !t.completed ? new Date().toISOString() : undefined }
        : t
    ));
  }, [currentUser]);

  const deleteTask = useCallback((taskId: string) => {
    if (!currentUser) return;
    
    const allTasks = getTasks();
    const filtered = allTasks.filter(t => !(t.id === taskId && t.userId === currentUser.id));
    saveTasks(filtered);
    setTasks(prev => prev.filter(t => t.id !== taskId));
    showMessage("Task deleted");
  }, [currentUser, showMessage]);

  const startEditTask = useCallback((task: Task) => {
    setEditingTaskId(task.id);
    setEditTitle(task.title);
  }, []);

  const saveEditTask = useCallback(() => {
    if (!editingTaskId || !editTitle.trim() || !currentUser) return;
    
    const allTasks = getTasks();
    const taskIndex = allTasks.findIndex(t => t.id === editingTaskId && t.userId === currentUser.id);
    if (taskIndex === -1) return;

    allTasks[taskIndex].title = editTitle.trim();
    saveTasks(allTasks);
    
    setTasks(prev => prev.map(t => 
      t.id === editingTaskId ? { ...t, title: editTitle.trim() } : t
    ));
    
    setEditingTaskId(null);
    setEditTitle("");
    showMessage("Task updated");
  }, [editingTaskId, editTitle, currentUser, showMessage]);

  // Admin login handler
  const handleAdminLogin = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    
    if (loginEmail === ADMIN_EMAIL && loginPassword === ADMIN_PASSWORD) {
      const users = getUsers();
      const admin = users.find(u => u.email === ADMIN_EMAIL);
      if (admin) {
        const token = generateToken(admin.id);
        saveSession({ token, userId: admin.id, expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000 });
        setCurrentUser(admin);
        setCurrentView("admin-dashboard");
        showMessage("Admin access granted");
        setLoginEmail("");
        setLoginPassword("");
      }
    } else {
      showMessage("Invalid admin credentials", true);
    }
  }, [loginEmail, loginPassword, showMessage]);

  // Categories
  const categories = [
    { id: "study", label: "Study", icon: "📚", color: "from-violet-500 to-purple-600" },
    { id: "workout", label: "Workout", icon: "💪", color: "from-emerald-500 to-teal-600" },
    { id: "work", label: "Work", icon: "💼", color: "from-blue-500 to-indigo-600" },
    { id: "personal", label: "Personal", icon: "✨", color: "from-pink-500 to-rose-600" },
    { id: "other", label: "Other", icon: "📌", color: "from-amber-500 to-orange-600" },
  ] as const;

  return (
    <div className="min-h-screen bg-[#030711] text-white antialiased selection:bg-violet-500/30 selection:text-white">
      <style>{`
        * { font-family: 'Space Grotesk', system-ui, -apple-system, sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: rgba(15, 23, 42, 0.5); }
        ::-webkit-scrollbar-thumb { background: rgba(99, 102, 241, 0.5); border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(99, 102, 241, 0.7); }
      `}</style>

      {/* Background effects */}
      <div className="fixed inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-[#030711] via-[#050b15] to-[#030711]" />
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-violet-600/10 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-indigo-600/10 rounded-full blur-[120px] animate-pulse [animation-delay:2s]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] border border-violet-500/[0.03] rounded-full" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-indigo-500/[0.05] rounded-full" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] border border-violet-500/[0.07] rounded-full" />
      </div>

      <div className="relative z-10 min-h-screen">
        {/* Header */}
        <header className="sticky top-0 z-40 backdrop-blur-2xl bg-slate-950/70 border-b border-slate-800/50">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex h-16 items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="absolute -inset-1 bg-gradient-to-r from-violet-600 to-indigo-600 rounded-xl blur opacity-60" />
                  <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-slate-900 border border-slate-800">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                      <path d="M3 12L9 18L21 6" stroke="url(#grad1)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                      <defs>
                        <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="#8b5cf6" />
                          <stop offset="100%" stopColor="#6366f1" />
                        </linearGradient>
                      </defs>
                    </svg>
                  </div>
                </div>
                <div>
                  <h1 className="text-lg font-semibold tracking-tight">HyperTrack</h1>
                  <p className="text-[10px] text-slate-500 font-mono tracking-widest -mt-1">NEURAL OS v2.4</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {currentUser && (
                  <>
                    <div className="hidden sm:flex items-center gap-3 px-3 py-1.5 rounded-lg bg-slate-900/50 border border-slate-800/50">
                      <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                      <span className="text-sm font-medium">{currentUser.username}</span>
                      {currentUser.isAdmin && (
                        <span className="px-2 py-0.5 text-[10px] font-mono font-bold tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded">
                          ROOT
                        </span>
                      )}
                    </div>
                    <button
                      onClick={handleLogout}
                      className="px-4 py-2 text-sm font-medium rounded-lg bg-slate-900/50 border border-slate-800 hover:bg-slate-800/50 hover:border-slate-700 transition-all"
                    >
                      Logout
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </header>

        <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
          {/* Home View */}
          {currentView === "home" && (
            <div className="min-h-[calc(100vh-200px)] flex items-center justify-center">
              <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-12 items-center">
                {/* Hero */}
                <div className="space-y-8">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-500/10 border border-violet-500/20 text-xs font-mono text-violet-300">
                    <span className="h-1.5 w-1.5 rounded-full bg-violet-400 animate-pulse" />
                    LIVE TRACKING ACTIVE
                  </div>
                  
                  <div className="space-y-4">
                    <h2 className="text-5xl lg:text-6xl font-bold tracking-tight leading-[1.1]">
                      Track your
                      <span className="block bg-gradient-to-r from-violet-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent">
                        daily evolution
                      </span>
                    </h2>
                    <p className="text-lg text-slate-400 leading-relaxed max-w-lg">
                      Military-grade habit tracking with real-time neural analytics. Built for peak performers.
                    </p>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { label: "Uptime", value: "99.9%" },
                      { label: "Latency", value: "<12ms" },
                      { label: "Users", value: "12.4k" },
                    ].map(stat => (
                      <div key={stat.label} className="p-4 rounded-xl bg-slate-900/30 border border-slate-800/50 backdrop-blur-sm">
                        <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">{stat.label}</div>
                        <div className="text-xl font-semibold font-mono mt-1">{stat.value}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Auth Card */}
                <div className="relative">
                  <div className="absolute -inset-1 bg-gradient-to-r from-violet-600/20 to-indigo-600/20 rounded-[2rem] blur-2xl" />
                  <div className="relative backdrop-blur-2xl bg-slate-900/70 border border-slate-800 rounded-[2rem] p-8 shadow-2xl">
                    <div className="flex rounded-xl bg-slate-950/50 p-1 mb-8 border border-slate-800">
                      {(["login", "register"] as const).map(mode => (
                        <button
                          key={mode}
                          onClick={() => { setAuthMode(mode); setError(""); setSuccess(""); }}
                          className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-medium capitalize transition-all ${
                            authMode === mode
                              ? "bg-slate-800 text-white shadow-lg shadow-slate-900/50"
                              : "text-slate-400 hover:text-slate-200"
                          }`}
                        >
                          {mode}
                        </button>
                      ))}
                    </div>

                    {error && (
                      <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-sm text-red-300">
                        {error}
                      </div>
                    )}
                    {success && (
                      <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-sm text-emerald-300">
                        {success}
                      </div>
                    )}

                    {authMode === "login" ? (
                      <form onSubmit={handleLogin} className="space-y-5">
                        <div className="space-y-4">
                          <div>
                            <label className="block text-[11px] font-mono text-slate-500 uppercase tracking-wider mb-2">Email Address</label>
                            <input
                              type="email"
                              value={loginEmail}
                              onChange={e => setLoginEmail(e.target.value)}
                              className="w-full px-4 py-3.5 rounded-xl bg-slate-950/50 border border-slate-800 text-white placeholder-slate-600 focus:border-violet-500/50 focus:outline-none focus:ring-4 focus:ring-violet-500/10 transition-all"
                              placeholder="you@domain.com"
                              required
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-mono text-slate-500 uppercase tracking-wider mb-2">Password</label>
                            <input
                              type="password"
                              value={loginPassword}
                              onChange={e => setLoginPassword(e.target.value)}
                              className="w-full px-4 py-3.5 rounded-xl bg-slate-950/50 border border-slate-800 text-white placeholder-slate-600 focus:border-violet-500/50 focus:outline-none focus:ring-4 focus:ring-violet-500/10 transition-all"
                              placeholder="••••••••"
                              required
                            />
                          </div>
                        </div>

                        <button
                          type="submit"
                          className="group relative w-full py-3.5 rounded-xl font-medium bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 transition-all shadow-lg shadow-violet-900/25 hover:shadow-violet-900/40"
                        >
                          <span className="relative z-10 flex items-center justify-center gap-2">
                            Access Dashboard
                            <svg className="w-4 h-4 transition-transform group-hover:translate-x-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                            </svg>
                          </span>
                        </button>

                        <div className="relative py-4">
                          <div className="absolute inset-0 flex items-center">
                            <div className="w-full border-t border-slate-800" />
                          </div>
                          <div className="relative flex justify-center">
                            <span className="px-4 text-[11px] font-mono text-slate-600 bg-slate-900">ADMINISTRATOR ACCESS</span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => setCurrentView("admin-login")}
                          className="w-full py-3 rounded-xl font-mono text-xs tracking-wider bg-slate-950/50 border border-amber-500/20 text-amber-300 hover:bg-amber-500/5 hover:border-amber-500/30 transition-all"
                        >
                          ⚡ ROOT ACCESS PORTAL
                        </button>
                      </form>
                    ) : (
                      <form onSubmit={handleRegister} className="space-y-5">
                        <div className="space-y-4">
                          <div>
                            <label className="block text-[11px] font-mono text-slate-500 uppercase tracking-wider mb-2">Username</label>
                            <input
                              type="text"
                              value={registerUsername}
                              onChange={e => setRegisterUsername(e.target.value)}
                              className="w-full px-4 py-3.5 rounded-xl bg-slate-950/50 border border-slate-800 text-white placeholder-slate-600 focus:border-violet-500/50 focus:outline-none focus:ring-4 focus:ring-violet-500/10 transition-all"
                              placeholder="johndoe"
                              required
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-mono text-slate-500 uppercase tracking-wider mb-2">Email Address</label>
                            <input
                              type="email"
                              value={registerEmail}
                              onChange={e => setRegisterEmail(e.target.value)}
                              className="w-full px-4 py-3.5 rounded-xl bg-slate-950/50 border border-slate-800 text-white placeholder-slate-600 focus:border-violet-500/50 focus:outline-none focus:ring-4 focus:ring-violet-500/10 transition-all"
                              placeholder="you@domain.com"
                              required
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-mono text-slate-500 uppercase tracking-wider mb-2">Password</label>
                            <input
                              type="password"
                              value={registerPassword}
                              onChange={e => setRegisterPassword(e.target.value)}
                              className="w-full px-4 py-3.5 rounded-xl bg-slate-950/50 border border-slate-800 text-white placeholder-slate-600 focus:border-violet-500/50 focus:outline-none focus:ring-4 focus:ring-violet-500/10 transition-all"
                              placeholder="Minimum 6 characters"
                              required
                            />
                          </div>
                        </div>

                        <button
                          type="submit"
                          className="group relative w-full py-3.5 rounded-xl font-medium bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 transition-all shadow-lg shadow-violet-900/25 hover:shadow-violet-900/40"
                        >
                          <span className="relative z-10 flex items-center justify-center gap-2">
                            Initialize Account
                            <svg className="w-4 h-4 transition-transform group-hover:translate-x-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                            </svg>
                          </span>
                        </button>
                      </form>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Admin Login */}
          {currentView === "admin-login" && (
            <div className="min-h-[calc(100vh-200px)] flex items-center justify-center">
              <div className="relative w-full max-w-md">
                <div className="absolute -inset-1 bg-gradient-to-r from-amber-600/20 to-orange-600/20 rounded-[2rem] blur-2xl" />
                <div className="relative backdrop-blur-2xl bg-slate-900/70 border border-amber-500/20 rounded-[2rem] p-8 shadow-2xl">
                  <button
                    onClick={() => setCurrentView("home")}
                    className="mb-6 flex items-center gap-2 text-sm text-slate-400 hover:text-slate-200 transition-colors"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                    </svg>
                    Back to login
                  </button>

                  <div className="text-center mb-8">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-500/30 mb-4">
                      <svg className="w-8 h-8 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                    </div>
                    <h2 className="text-2xl font-bold">Administrator Access</h2>
                    <p className="text-sm text-slate-400 font-mono mt-1">RESTRICTED ZONE</p>
                  </div>

                  {error && (
                    <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-sm text-red-300">
                      {error}
                    </div>
                  )}

                  <form onSubmit={handleAdminLogin} className="space-y-5">
                    <div>
                      <label className="block text-[11px] font-mono text-slate-500 uppercase tracking-wider mb-2">Root Email</label>
                      <input
                        type="email"
                        value={loginEmail}
                        onChange={e => setLoginEmail(e.target.value)}
                        className="w-full px-4 py-3.5 rounded-xl bg-slate-950/50 border border-slate-800 text-white placeholder-slate-600 focus:border-amber-500/50 focus:outline-none focus:ring-4 focus:ring-amber-500/10 transition-all font-mono"
                        placeholder="root.hyper@cloud.com"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-mono text-slate-500 uppercase tracking-wider mb-2">Access Key</label>
                      <input
                        type="password"
                        value={loginPassword}
                        onChange={e => setLoginPassword(e.target.value)}
                        className="w-full px-4 py-3.5 rounded-xl bg-slate-950/50 border border-slate-800 text-white placeholder-slate-600 focus:border-amber-500/50 focus:outline-none focus:ring-4 focus:ring-amber-500/10 transition-all font-mono"
                        placeholder="••••••••"
                        required
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-xl font-mono text-sm tracking-wider bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 transition-all shadow-lg shadow-amber-900/25"
                    >
                      AUTHENTICATE ROOT
                    </button>
                  </form>

                  <div className="mt-6 p-3 rounded-xl bg-slate-950/50 border border-slate-800">
                    <p className="text-[10px] font-mono text-slate-500 text-center">Demo credentials provided in requirements</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* User Dashboard */}
          {currentView === "dashboard" && currentUser && (
            <div className="space-y-8">
              {/* Stats bar */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: "COMPLETION", value: `${completionPercentage}%`, sub: `${completedTasks.length}/${todayTasks.length}`, color: "from-violet-500 to-indigo-600" },
                  { label: "STREAK", value: `${streak}`, sub: "days", color: "from-emerald-500 to-teal-600" },
                  { label: "PENDING", value: `${pendingTasks.length}`, sub: "tasks", color: "from-amber-500 to-orange-600" },
                  { label: "TODAY", value: `${todayTasks.length}`, sub: "total", color: "from-blue-500 to-indigo-600" },
                ].map(stat => (
                  <div key={stat.label} className="relative group">
                    <div className={`absolute -inset-0.5 bg-gradient-to-r ${stat.color} rounded-2xl blur opacity-20 group-hover:opacity-30 transition-opacity`} />
                    <div className="relative backdrop-blur-xl bg-slate-900/50 border border-slate-800/50 rounded-2xl p-5">
                      <div className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">{stat.label}</div>
                      <div className="flex items-baseline gap-2 mt-2">
                        <div className="text-3xl font-bold tracking-tight">{stat.value}</div>
                        <div className="text-sm text-slate-500">{stat.sub}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="grid lg:grid-cols-3 gap-8">
                {/* Tasks */}
                <div className="lg:col-span-2 space-y-6">
                  {/* Add task */}
                  <div className="relative">
                    <div className="absolute -inset-0.5 bg-gradient-to-r from-violet-600/20 to-indigo-600/20 rounded-[1.5rem] blur" />
                    <div className="relative backdrop-blur-2xl bg-slate-900/70 border border-slate-800 rounded-[1.5rem] p-6">
                      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-violet-500 animate-pulse" />
                        New Task Protocol
                      </h3>
                      
                      <form onSubmit={handleAddTask} className="space-y-4">
                        <div className="flex gap-3">
                          <input
                            type="text"
                            value={newTaskTitle}
                            onChange={e => setNewTaskTitle(e.target.value)}
                            placeholder="Enter task objective..."
                            className="flex-1 px-4 py-3 rounded-xl bg-slate-950/70 border border-slate-800 text-white placeholder-slate-600 focus:border-violet-500/50 focus:outline-none focus:ring-4 focus:ring-violet-500/10 transition-all"
                            required
                          />
                          <button
                            type="submit"
                            className="px-6 py-3 rounded-xl font-medium bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 transition-all shadow-lg shadow-violet-900/25"
                          >
                            Deploy
                          </button>
                        </div>

                        <div className="flex gap-2 flex-wrap">
                          {categories.map(cat => (
                            <button
                              key={cat.id}
                              type="button"
                              onClick={() => setNewTaskCategory(cat.id)}
                              className={`px-3 py-2 rounded-lg text-sm font-medium border transition-all ${
                                newTaskCategory === cat.id
                                  ? "bg-slate-800 border-slate-700 text-white"
                                  : "bg-slate-950/50 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                              }`}
                            >
                              <span className="mr-1.5">{cat.icon}</span>
                              {cat.label}
                            </button>
                          ))}
                        </div>
                      </form>
                    </div>
                  </div>

                  {/* Task lists */}
                  <div className="grid md:grid-cols-2 gap-6">
                    {/* Pending */}
                    <div className="backdrop-blur-2xl bg-slate-900/50 border border-slate-800/50 rounded-[1.5rem] p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold flex items-center gap-2">
                          <div className="h-2 w-2 rounded-full bg-amber-500" />
                          Pending
                          <span className="px-2 py-0.5 text-xs font-mono bg-slate-800 rounded-md">{pendingTasks.length}</span>
                        </h3>
                      </div>

                      <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2 -mr-2">
                        {pendingTasks.length === 0 ? (
                          <div className="py-12 text-center">
                            <div className="text-4xl mb-3 opacity-20">✓</div>
                            <p className="text-sm text-slate-500 font-mono">ALL SYSTEMS CLEAR</p>
                          </div>
                        ) : (
                          pendingTasks.map(task => {
                            const category = categories.find(c => c.id === task.category)!;
                            return (
                              <div
                                key={task.id}
                                className="group relative p-4 rounded-xl bg-slate-950/50 border border-slate-800 hover:border-slate-700 transition-all"
                              >
                                <div className="flex items-start gap-3">
                                  <button
                                    onClick={() => toggleTask(task.id)}
                                    className="mt-0.5 flex-shrink-0 w-5 h-5 rounded-md border-2 border-slate-700 hover:border-violet-500 transition-colors"
                                  />
                                  
                                  {editingTaskId === task.id ? (
                                    <div className="flex-1 flex gap-2">
                                      <input
                                        type="text"
                                        value={editTitle}
                                        onChange={e => setEditTitle(e.target.value)}
                                        className="flex-1 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-sm focus:outline-none focus:border-violet-500"
                                        autoFocus
                                        onKeyDown={e => {
                                          if (e.key === "Enter") saveEditTask();
                                          if (e.key === "Escape") setEditingTaskId(null);
                                        }}
                                      />
                                      <button
                                        onClick={saveEditTask}
                                        className="px-3 py-1.5 rounded-lg bg-violet-600 text-xs font-medium hover:bg-violet-500"
                                      >
                                        Save
                                      </button>
                                    </div>
                                  ) : (
                                    <>
                                      <div className="flex-1 min-w-0">
                                        <p className="font-medium truncate">{task.title}</p>
                                        <div className="flex items-center gap-2 mt-1.5">
                                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded-md bg-gradient-to-r ${category.color} bg-opacity-20`}>
                                            {category.icon} {category.label}
                                          </span>
                                          <span className="text-[10px] font-mono text-slate-600">
                                            {new Date(task.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                                          </span>
                                        </div>
                                      </div>
                                      
                                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button
                                          onClick={() => startEditTask(task)}
                                          className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                                        >
                                          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                          </svg>
                                        </button>
                                        <button
                                          onClick={() => deleteTask(task.id)}
                                          className="p-1.5 rounded-lg hover:bg-red-500/10 text-slate-400 hover:text-red-400 transition-colors"
                                        >
                                          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                          </svg>
                                        </button>
                                      </div>
                                    </>
                                  )}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>

                    {/* Completed */}
                    <div className="backdrop-blur-2xl bg-slate-900/50 border border-slate-800/50 rounded-[1.5rem] p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold flex items-center gap-2">
                          <div className="h-2 w-2 rounded-full bg-emerald-500" />
                          Completed
                          <span className="px-2 py-0.5 text-xs font-mono bg-slate-800 rounded-md">{completedTasks.length}</span>
                        </h3>
                      </div>

                      <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2 -mr-2">
                        {completedTasks.length === 0 ? (
                          <div className="py-12 text-center">
                            <div className="text-4xl mb-3 opacity-20">○</div>
                            <p className="text-sm text-slate-500 font-mono">AWAITING EXECUTION</p>
                          </div>
                        ) : (
                          completedTasks.map(task => {
                            const category = categories.find(c => c.id === task.category)!;
                            return (
                              <div
                                key={task.id}
                                className="group relative p-4 rounded-xl bg-slate-950/30 border border-slate-800/50 opacity-75"
                              >
                                <div className="flex items-start gap-3">
                                  <button
                                    onClick={() => toggleTask(task.id)}
                                    className="mt-0.5 flex-shrink-0 w-5 h-5 rounded-md bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center"
                                  >
                                    <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                    </svg>
                                  </button>
                                  
                                  <div className="flex-1 min-w-0">
                                    <p className="font-medium line-through text-slate-500 truncate">{task.title}</p>
                                    <div className="flex items-center gap-2 mt-1.5">
                                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-slate-500">
                                        {category.icon} {category.label}
                                      </span>
                                      <span className="text-[10px] font-mono text-slate-600">
                                        ✓ {task.completedAt ? new Date(task.completedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""}
                                      </span>
                                    </div>
                                  </div>
                                  
                                  <button
                                    onClick={() => deleteTask(task.id)}
                                    className="p-1.5 rounded-lg hover:bg-red-500/10 text-slate-600 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100"
                                  >
                                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                    </svg>
                                  </button>
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Analytics sidebar */}
                <div className="space-y-6">
                  {/* Progress ring */}
                  <div className="relative">
                    <div className="absolute -inset-0.5 bg-gradient-to-r from-violet-600/20 to-indigo-600/20 rounded-[1.5rem] blur" />
                    <div className="relative backdrop-blur-2xl bg-slate-900/70 border border-slate-800 rounded-[1.5rem] p-6">
                      <h3 className="font-semibold mb-6">Neural Progress</h3>
                      
                      <div className="relative w-40 h-40 mx-auto">
                        <svg className="w-full h-full -rotate-90">
                          <circle cx="80" cy="80" r="70" fill="none" stroke="rgba(51, 65, 85, 0.3)" strokeWidth="12" />
                          <circle
                            cx="80" cy="80" r="70"
                            fill="none"
                            stroke="url(#progressGrad)"
                            strokeWidth="12"
                            strokeLinecap="round"
                            strokeDasharray={`${2 * Math.PI * 70}`}
                            strokeDashoffset={`${2 * Math.PI * 70 * (1 - completionPercentage / 100)}`}
                            className="transition-all duration-1000"
                          />
                          <defs>
                            <linearGradient id="progressGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" stopColor="#8b5cf6" />
                              <stop offset="100%" stopColor="#6366f1" />
                            </linearGradient>
                          </defs>
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                          <div className="text-4xl font-bold font-mono">{completionPercentage}</div>
                          <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider mt-1">Percent</div>
                        </div>
                      </div>

                      <div className="mt-6 space-y-3">
                        {[
                          { label: "Tasks Complete", value: completedTasks.length, total: todayTasks.length, color: "bg-emerald-500" },
                          { label: "Remaining", value: pendingTasks.length, total: todayTasks.length, color: "bg-amber-500" },
                        ].map(item => (
                          <div key={item.label} className="space-y-2">
                            <div className="flex justify-between text-xs">
                              <span className="text-slate-400 font-mono">{item.label}</span>
                              <span className="font-mono">{item.value}/{item.total}</span>
                            </div>
                            <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                              <div
                                className={`h-full ${item.color} transition-all duration-700`}
                                style={{ width: `${item.total ? (item.value / item.total) * 100 : 0}%` }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Quick stats */}
                  <div className="backdrop-blur-2xl bg-slate-900/50 border border-slate-800/50 rounded-[1.5rem] p-6">
                    <h3 className="font-semibold mb-4">System Metrics</h3>
                    <div className="space-y-3">
                      {[
                        { label: "Current Streak", value: `${streak} days`, icon: "🔥" },
                        { label: "Total Tasks", value: tasks.length.toString(), icon: "📊" },
                        { label: "Avg Completion", value: `${Math.round(chartData.reduce((a, b) => a + b.completion, 0) / 7)}%`, icon: "⚡" },
                      ].map(metric => (
                        <div key={metric.label} className="flex items-center justify-between py-2 border-b border-slate-800/50 last:border-0">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{metric.icon}</span>
                            <span className="text-sm text-slate-400">{metric.label}</span>
                          </div>
                          <span className="font-mono font-medium">{metric.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Trading chart */}
              <div className="relative">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-violet-600/10 to-indigo-600/10 rounded-[1.5rem] blur" />
                <div className="relative backdrop-blur-2xl bg-slate-900/70 border border-slate-800 rounded-[1.5rem] p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h3 className="text-lg font-semibold flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-violet-500 animate-pulse" />
                        Performance Analytics
                      </h3>
                      <p className="text-xs font-mono text-slate-500 mt-1">7-DAY COMPLETION TREND • REAL-TIME</p>
                    </div>
                    <div className="flex items-center gap-4 text-xs font-mono">
                      <div className="flex items-center gap-1.5">
                        <div className="w-3 h-0.5 bg-violet-500 rounded-full" />
                        <span className="text-slate-400">COMPLETION %</span>
                      </div>
                      <div className="px-2 py-1 rounded-md bg-slate-800 text-slate-300">
                        LIVE
                      </div>
                    </div>
                  </div>
                  
                  <TradingChart data={chartData} />
                </div>
              </div>
            </div>
          )}

          {/* Admin Dashboard */}
          {currentView === "admin-dashboard" && currentUser?.isAdmin && (
            <div className="space-y-8">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold">Admin Control Center</h2>
                  <p className="text-slate-400 font-mono text-sm mt-1">ROOT ACCESS • SYSTEM OVERVIEW</p>
                </div>
                <div className="px-4 py-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 font-mono text-sm">
                  ● ADMIN MODE
                </div>
              </div>

              {/* Admin stats */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {(() => {
                  const users = getUsers();
                  const allTasks = getTasks();
                  const totalUsers = users.filter(u => !u.isAdmin).length;
                  const totalTasks = allTasks.length;
                  const completedAll = allTasks.filter(t => t.completed).length;
                  const avgCompletion = totalTasks > 0 ? Math.round((completedAll / totalTasks) * 100) : 0;
                  
                  return [
                    { label: "TOTAL USERS", value: totalUsers.toString(), icon: "👥" },
                    { label: "TOTAL TASKS", value: totalTasks.toString(), icon: "📋" },
                    { label: "COMPLETED", value: completedAll.toString(), icon: "✓" },
                    { label: "AVG RATE", value: `${avgCompletion}%`, icon: "📈" },
                  ].map(stat => (
                    <div key={stat.label} className="backdrop-blur-xl bg-slate-900/50 border border-slate-800/50 rounded-2xl p-5">
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">{stat.label}</div>
                        <span className="text-lg">{stat.icon}</span>
                      </div>
                      <div className="text-3xl font-bold font-mono">{stat.value}</div>
                    </div>
                  ));
                })()}
              </div>

              {/* Users table */}
              <div className="relative">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-slate-600/10 to-slate-700/10 rounded-[1.5rem] blur" />
                <div className="relative backdrop-blur-2xl bg-slate-900/70 border border-slate-800 rounded-[1.5rem] overflow-hidden">
                  <div className="p-6 border-b border-slate-800">
                    <h3 className="text-lg font-semibold">Registered Users</h3>
                    <p className="text-xs font-mono text-slate-500 mt-1">COMPLETE USER DATABASE</p>
                  </div>
                  
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-slate-950/50 border-b border-slate-800">
                        <tr>
                          {["USER", "EMAIL", "JOINED", "TASKS", "COMPLETED", "RATE"].map(head => (
                            <th key={head} className="text-left px-6 py-3 text-[10px] font-mono text-slate-500 uppercase tracking-wider">
                              {head}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/50">
                        {getUsers().filter(u => !u.isAdmin).map(user => {
                          const userTasks = getTasks().filter(t => t.userId === user.id);
                          const completed = userTasks.filter(t => t.completed).length;
                          const rate = userTasks.length > 0 ? Math.round((completed / userTasks.length) * 100) : 0;
                          
                          return (
                            <tr key={user.id} className="hover:bg-slate-900/30 transition-colors">
                              <td className="px-6 py-4">
                                <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500/20 to-indigo-500/20 border border-violet-500/20 flex items-center justify-center text-xs font-mono">
                                    {user.username.slice(0, 2).toUpperCase()}
                                  </div>
                                  <span className="font-medium">{user.username}</span>
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <span className="font-mono text-sm text-slate-300">{user.email}</span>
                              </td>
                              <td className="px-6 py-4">
                                <span className="text-sm font-mono text-slate-400">
                                  {new Date(user.createdAt).toLocaleDateString()}
                                </span>
                              </td>
                              <td className="px-6 py-4">
                                <span className="font-mono">{userTasks.length}</span>
                              </td>
                              <td className="px-6 py-4">
                                <span className="font-mono text-emerald-400">{completed}</span>
                              </td>
                              <td className="px-6 py-4">
                                <div className="flex items-center gap-3">
                                  <div className="w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                    <div 
                                      className="h-full bg-gradient-to-r from-violet-500 to-indigo-500 transition-all"
                                      style={{ width: `${rate}%` }}
                                    />
                                  </div>
                                  <span className="font-mono text-sm w-10">{rate}%</span>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                        {getUsers().filter(u => !u.isAdmin).length === 0 && (
                          <tr>
                            <td colSpan={6} className="px-6 py-12 text-center">
                              <div className="text-slate-500 font-mono text-sm">NO REGISTERED USERS</div>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Recent activity */}
              <div className="backdrop-blur-2xl bg-slate-900/50 border border-slate-800/50 rounded-[1.5rem] p-6">
                <h3 className="font-semibold mb-4">Recent System Activity</h3>
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {getTasks()
                    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                    .slice(0, 10)
                    .map(task => {
                      const user = getUsers().find(u => u.id === task.userId);
                      return (
                        <div key={task.id} className="flex items-center gap-3 p-3 rounded-xl bg-slate-950/50 border border-slate-800/50 text-sm">
                          <div className={`w-2 h-2 rounded-full ${task.completed ? "bg-emerald-500" : "bg-amber-500"}`} />
                          <span className="font-mono text-slate-500">
                            {new Date(task.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                          </span>
                          <span className="text-slate-300">{user?.username || "Unknown"}</span>
                          <span className="text-slate-500">created</span>
                          <span className="font-medium truncate flex-1">{task.title}</span>
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono ${
                            task.completed 
                              ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                              : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                          }`}>
                            {task.completed ? "DONE" : "PENDING"}
                          </span>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          )}
        </main>

        {/* Footer */}
        <footer className="mt-16 border-t border-slate-800/50 backdrop-blur-2xl bg-slate-950/50">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
              <p className="text-sm text-slate-500 font-mono">
                Made by Aarav Mehroliya – All Rights Reserved
              </p>
              <div className="flex items-center gap-4 text-[10px] font-mono text-slate-600 uppercase tracking-wider">
                <span>Neural OS v2.4</span>
                <span className="hidden sm:inline">•</span>
                <span>Secure • Encrypted • Real-time</span>
              </div>
            </div>
          </div>
        </footer>

        {/* Toast notifications */}
        {(error || success) && (
          <div className="fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-4">
            <div className={`px-4 py-3 rounded-xl backdrop-blur-2xl border shadow-2xl flex items-center gap-3 ${
              error 
                ? "bg-red-950/90 border-red-800/50 text-red-200" 
                : "bg-emerald-950/90 border-emerald-800/50 text-emerald-200"
            }`}>
              <div className={`w-2 h-2 rounded-full ${error ? "bg-red-400" : "bg-emerald-400"} animate-pulse`} />
              <span className="text-sm font-medium">{error || success}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}